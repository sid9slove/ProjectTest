//
//  Setting.h
//  Planner
//
//  Created by Hanke on 13/07/15.
//  Copyright (c) 2015 Caroline. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Setting : UIViewController

@end
