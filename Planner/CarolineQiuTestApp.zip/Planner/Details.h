//
//  Details.h
//  Planner
//
//  Created by Hanke on 16/07/15.
//  Copyright (c) 2015 Caroline. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SubjectModle;
@interface Details : UIView //need change to uiview controller
//@property (nonatomic, assign) id<DetailsDelegate> delagate;
@property (nonatomic, strong) SubjectModle *contactModel;


@end

